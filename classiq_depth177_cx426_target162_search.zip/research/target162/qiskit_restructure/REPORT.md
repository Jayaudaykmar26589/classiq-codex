# qiskit_restructure

Two restructuring rounds completed under the common evaluation settings.

| Trial | Depth | CX | Width | All 4096 | Both target limits |
|---|---:|---:|---:|---|---|
| round1_commute_blocks | 177 | 426 | 18 | True | False |
| round1_global_commute | 177 | 426 | 18 | True | False |
| round2_reverse_commute_blocks | 177 | 426 | 18 | True | False |
| round2_reverse_global_commute | 177 | 426 | 18 | True | False |

These compiler passes preserve the full unitary in their specified exact mode; the numerical native oracle is independently verified. No cloud synthesis or official score is claimed. The incumbent is retained when trials regress. Compiler block partition and local-equivalence transformations do not replace the entire Boolean encoding, which remains the main structural limitation. A broader reachable-subspace topology replacement is the next candidate if local synthesis does not reduce depth.
