# Target 162 depth / 354 CX: two-round results

**No verified circuit beat 162/354. The best available tuple remains (177 depth, 426 CX, 18 qubits).** Five tracks completed two restructuring rounds each. Three specialist agents ran alongside the parent, which evaluated the two library tracks. The agreed stopping condition is reached; the broader leaderboard objective remains unachieved.

Depth is the primary ranking key: depth 161 would beat 162/354 regardless of CX, while a depth-162 circuit would need CX at most 353. We additionally tracked the stronger simultaneous target depth below 162 and CX below 354. Neither outcome was achieved. The benchmark is user-supplied; a current official rank was not checked.

The final columns retain the verified incumbent when a restructuring regresses or fails correctness. They must not be interpreted as five independently discovered winning architectures. All five tracks use the same 177/426 baseline.

| Rank | Architecture / optimization track | Baseline depth | Baseline CX | Final depth | Final CX | Width | Beats 162/354 | Key changes | Correctness |
|---:|---|---:|---:|---:|---:|---:|---|---|---|
| 1 | Whole-side isometry refits | 177 | 426 | 177 | 426 | 18 | No | Single then paired CX deletions; 48 fits | All 4096 pass; incumbent retained |
| 2 | Joint scheduling and CX directions | 177 | 426 | 177 | 426 | 18 | No | Alternate direction changes, commuting schedules and fusion | All 4096 pass; incumbent retained |
| 3 | Cross-side eight-wire resynthesis | 177 | 426 | 177 | 426 | 18 | No | Two-CX removal; then rewired CX and additional rotations | All 4096 pass; incumbent retained |
| 4 | Qiskit block restructuring | 177 | 426 | 177 | 426 | 18 | No | Commuting two-qubit resynthesis; reverse traversal | All 4096 pass; incumbent retained |
| 5 | pytket multiqubit restructuring | 177 | 426 | 177 | 426 | 18 | No | Multiqubit squash; reversed synthesis traversal | All 4096 pass; incumbent retained |

Ranks are tied on depth and CX; row order only identifies the tracks. Every retained result also fails the earlier depth<177 requirement.

## What the experiments established

The whole-side track screened 1,231 additional deletion topologies, priced 83 probes and ran 48 stable phase-aware numerical fits. Its selected round-one diagnostics were 177/425 and round-two diagnostics 177/424; all four failed complete oracle verification. The previously successful two-gate reduction from 428 to 426 CX does not extend to these additional fixed-position deletions within this search.

Cross-side resynthesis fitted occupied subspaces of rank 48 and 96 in two eight-wire windows. Four two-CX-deletion templates and eight rewired templates did not recover the required complex maps. Selected full diagnostics scored 177/424 and 178/425 but failed verification. Deleting those entire windows gives fixed-outside gate-list floors of 169/414 and 170/415. Those scoped floors do not account for wider boundary cancellations under recompilation and do not prove a bound on other architectures.

Qiskit commuting and block resynthesis, including reverse traversal, retained 177/426. pytket multiqubit and peephole variants were valid but scored 179–181 depth with 426 CX, so were rejected. The joint scheduling track did not reduce depth or CX. Exact per-round evidence and bounded search settings are linked below.

## Verification and comparison

All complete candidates use Qiskit 2.5.2, u3/cx basis, all-to-all connectivity, optimization level 3, seed 42, qubits_initially_zero=False, exactly 18 wires, and no measurement, reset, initialization or barriers. The final compilation settings are identical even when an earlier restructuring pass uses another library. Native metrics include the full oracle and helper cleanup, excluding state preparation. Numerical fits and structural probes are not treated as verified oracles.

The retained deliverable passes all 4096 computational inputs, marks exactly 1097 pixels, restores the coordinates and six clean helpers, and matches the required relative phases up to one common global phase. Maximum observed error plus sparse-discard bound is 8.151e-12; helper leakage is at most 2.971e-23. QASM/QMOD have identical 816-operation numeric bodies. No new Classiq cloud synthesis or official score is claimed. The SDK probe was built locally; QMOD targets the Model text editor, with Graphical upload compatibility unestablished.

To meet both stronger limits from the retained circuit requires at least 16 fewer depth layers and 73 fewer CX gates. The next useful search would jointly redesign a larger encoder/phase-consumer region and its boundary interactions, rather than further isolated gate deletions or another local compiler pass. That is a proposed next direction, not a demonstrated winning architecture.

## Track evidence

- [Whole-side isometry refits](side_refit/REPORT.md): No accepted repair; lower-CX diagnostics fail phase or cleanup. Next change: Replace a larger interacting region and change rotation positions.
- [Joint scheduling and CX directions](joint_schedule/REPORT.md): No depth/CX improvement. Next change: Change the entangling topology across dependency boundaries.
- [Cross-side eight-wire resynthesis](wide_resynthesis/REPORT.md): Both selected complete diagnostics fail verification. Next change: Expand beyond these isolated windows; preserve phase in the joint objective.
- [Qiskit block restructuring](qiskit_restructure/REPORT.md): Retains 177/426. Next change: Use reachable-subspace synthesis over broader interacting blocks.
- [pytket multiqubit restructuring](pytket_restructure/REPORT.md): Best emitted result regresses to 179/426. Next change: Replace the encoding rather than repeat exact local peephole passes.

The machine-readable SUMMARY.json and LEADERBOARD.md contain candidate status and links to every complete evaluation. Original source artifacts remain unchanged.
