# Local candidate leaderboard

Baseline: (177 depth, 426 CX, 18 qubits), all 4096 inputs verified. Latest benchmark: 162 depth / 354 CX. Numerical scores below are local, not official platform scores.

| Track / trial | Depth | CX | Width | Verified | Beats 162/354 |
|---|---:|---:|---:|---|---|
| joint_schedule / baseline_common | 177 | 426 | 18 | True | False |
| joint_schedule / round1_common | 177 | 426 | 18 | True | False |
| joint_schedule / round2_common | 177 | 426 | 18 | True | False |
| qiskit_restructure / round1_commute_blocks | 177 | 426 | 18 | True | False |
| qiskit_restructure / round1_global_commute | 177 | 426 | 18 | True | False |
| qiskit_restructure / round2_reverse_commute_blocks | 177 | 426 | 18 | True | False |
| qiskit_restructure / round2_reverse_global_commute | 177 | 426 | 18 | True | False |
| joint_schedule / sanity | 179 | 426 | 18 | True | False |
| pytket_restructure / round1_three_qubit | 179 | 426 | 18 | True | False |
| pytket_restructure / round1_commute_full | 181 | 426 | 18 | True | False |
| pytket_restructure / round2_commute_full | 181 | 426 | 18 | True | False |
| pytket_restructure / round2_three_qubit | 181 | 426 | 18 | True | False |
| side_refit / x_best_invalid_diagnostic | 177 | 424 | 18 | False | False |
| side_refit / y_best_invalid_diagnostic | 177 | 424 | 18 | False | False |
| wide_resynthesis / round1_DIAGNOSTIC | 177 | 424 | 18 | False | False |
| side_refit / x_best_invalid_diagnostic | 177 | 425 | 18 | False | False |
| side_refit / y_best_invalid_diagnostic | 177 | 425 | 18 | False | False |
| wide_resynthesis / round2_DIAGNOSTIC | 178 | 425 | 18 | False | False |
