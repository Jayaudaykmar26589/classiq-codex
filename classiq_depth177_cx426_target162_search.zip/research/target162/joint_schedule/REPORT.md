# Joint CX-frame and commuting-schedule track

Two restructuring rounds completed. The retained complete oracle is **(depth177,CX426,width18)** with389U3gates. It passes strict native verification on all4096inputs. It neither meets both requested limits (`depth<162` and `CX<354`) nor beats the162/354benchmark lexicographically.

| Stage | Depth | CX | Width | U3 | Correctness | Result type |
|---|---:|---:|---:|---:|---|---|
| Common-compiled baseline |177|426|18|390|All4096pass|Baseline|
| Round1 retained output |177|426|18|389|All4096pass|One fewerU3; leaderboard-score tie|
| Round2 retained output |177|426|18|389|All4096pass|Round1incumbent retained; no new improvement|

## Round1: orientation changes followed by new commuting schedules

Every one of the426CXgates was independently reversed using Hadamard conjugation, alongside the unmodified frame. Each frame was then subject to single-qubit fusion, carrying commuting single-qubit gates throughCXoperations, cancellation of equalCXgates when allowed, and two fresh commutation-DAG scheduling priorities. The DAG is rebuilt after the frame change: this combines direction changes and reorderings rather than repeating either previous independent model.

The427frame choices produced1708scored forms in23.45seconds. The best retained output reverses sourceCX280and fuses the surrounding single-qubit gates, saving oneU3. The additionally tested joint reorderings did not improve depth orCX, so the simpler intermediate frame rewrite was retained. A separately verified diagnostic combined schedule measures179/426; it was not promoted.

## Round2: compound frame changes and alternating schedules

The second round starts from the retained restructured circuit and applies sets of1–8CXdirection changes. It alternates newly rebuilt commuting schedules, commuting one-qubit propagation, fusion, and eligibleCXcancellation, with plateau walks and restarts. It tested1500compound mutations and4500scored forms in58.01seconds. No trial improved the retained tuple; `round2_common.qasm` therefore contains the round1incumbent, not a newly improved round2circuit.

As a bounded model check within this combined round,142selected frame choices were separately subjected to exact depth176commuting-schedule feasibility models. All142returnedINFEASIBLE within55.21seconds total. These are new commuting models after the direction changes; they do not rely on the earlier separate fixed-source/fixed-order proofs. They cover only the selected frame choices and are not a global impossibility result for joint frame changes and scheduling.

## Verification and comparison settings

The baseline and both retained round outputs were freshly compiled with Qiskit2.5.2, U3/CX basis, all-to-all coupling, optimization_level3, seed_transpiler42, qubits_initially_zero=False, exactly18qubits, and no measurement/reset/initialization/barriers. Every full output passes the strict4096-input verifier, including1097markedpixels and restored helpers. Maximum error plus discarded bound is8.20e-12 and maximum reported helper leakage is2.98e-23.

`iterations.json` contains the three complete evaluations. Each record explicitly includes the **latest** target fields `both_target_limits_met` and `leaderboard_lexicographic_win`; inherited helper fields referring to the older177/428target are not used to decide success here. Both latest-target flags arefalse for every retained output.

`search.json` records both restructuring rounds. `joint_cp.json` records the142combined orientation-and-scheduling model checks. `round1_common.qasm` and `round2_common.qasm` are the verified retained outputs. Protected outputs were not changed.

The bottleneck is the remaining nonlinear interaction sequence: these exact local frame/reordering changes have not removed enough interactions or critical-path dependencies. A promising next change is a larger logical replacement of overlapping compute/phase blocks, rather than repeating these sampled discrete scheduling forms. The track stops after the requested two rounds.
