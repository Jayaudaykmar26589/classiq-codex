# Target162 track: wider cross-side reachable-isometry resynthesis

The two agreed restructuring rounds are complete. Neither produced a valid improved oracle. The best valid circuit retained by this track is the incoming **depth177/CX426/width18** oracle; it fails the new strict limits and does not beat the162/354 reference.

| Stage | Depth | CX | Width | Correctness | Both <162 / <354 |
|---|---:|---:|---:|---|---|
| Incoming verified baseline |177|426|18|Verified incumbent|No|
| Round1 selected diagnostic |177|424|18|Native4096 FAIL|No|
| Round2 selected diagnostic |178|425|18|Native4096 FAIL|No|
| Retained best valid result |177|426|18|Verified incumbent|No|

The diagnostic QASM files are research evidence, not submission candidates. No QMOD was generated for an invalid diagnostic, and protected output files were not modified.

## New wider contracts

This branch searched maximal seven/eight-wire islands on the new426-CX circuit, excluding entire nine-wire side blocks and the previously tested two-wire/gauge families. It found364 qualifying cross-side windows, with84 distinct finalists. The two selected windows are:

| Round | Native indices | Global wires | Original local gates/CX | Occupied support |
|---|---|---|---:|---:|
|1|586–610 inclusive|6,7,8,12,14,15,16,17|25/12|48/256|
|2|717–735 inclusive|3,5,9,11,12,14,15,17|19/11|96/256|

For each window, the current source was propagated through the window's input cut on **all4,096 clean coordinate inputs**. Tracing out the other ten wires and summing reduced densities produced the occupied local subspace. The smallest retained density eigenvalues are4 and2, respectively; the largest nominally zero eigenvalue magnitude is below3e-13. A1e-8 support threshold therefore has a wide numerical separation. The exact native block was applied to an orthonormal basis for this support to obtain the state-and-phase target. This preserves correlations with the other wires whenever a fitted replacement matches the complete support isometry.

## Round1: simultaneous entangler removal

All66 pairs of the first window's12CX operations were deletion-screened. Four low-loss templates were selected, removing two CX simultaneously while refitting every existing U3 slot across all eight wires. This differs from the earlier single-deletion six-wire fit and the whole-side nine-wire refits.

Each fit used SciPy L-BFGS-B with an analytic adjoint gradient, an independently checked finite-difference gradient, and at most100 iterations. None matched the48-column state-and-phase contract. The best maximum support-column error was0.9663. Two other templates reached syntactic depth176/CX424 but had support errors above1.10 and are invalid.

The selected full circuit recompiles to177/424/18. Independent native verification checks all4,096 inputs and rejects it: maximum oracle amplitude error0.9854. Helper leakage is small, demonstrating that phase/state correctness cannot be inferred from clean helpers or favorable resource counts.

## Round2: changed entangler connectivity and additional rotation freedom

The second window's55 two-CX deletion choices were screened. Eight new templates were then formed from the two leading choices: remove one CX, change the other interaction to one of four different directed pairs, and add a full eight-wire U3 layer at the window midpoint. All old and new U3 parameters were jointly refitted against the96-column reachable isometry.

No template passed the1e-9 local acceptance criterion. The best maximum support-column error was1.2786. The selected full circuit measures178/425/18 and fails the all4,096 native verifier, with maximum oracle amplitude error0.8174 and helper leakage probability0.9667. Other templates have different resource counts, including177/423, but all are invalid; every fit's metrics and error are recorded in `round2_results.json`.

## Evaluation settings and limits of the conclusion

All complete diagnostic circuits use the shared Qiskit2.5.2 contract: U3/CX basis, all-to-all (`coupling_map=None`), optimization level3, seed42, `qubits_initially_zero=False`, no measurements/resets/initialization/barriers, and exactly18 qubits. Every selected diagnostic receives the independent full-input native verifier. The evaluation JSON explicitly adds the current strict target test (`depth<162 AND CX<354`) and the separate leaderboard-reference test (`depth<162 OR depth==162 AND CX<354`), both requiring width18 and successful verification.

Deleting the entire first or second window while retaining the outside native gate list gives169/414 or170/415, respectively. These are **fixed-outside gate-list floors**, not general resynthesis lower bounds. Boundary cancellations or a rewrite of additional outside operations could invalidate that simple model. They do show why an isolated small window, without substantial effects beyond its boundaries, cannot supply the required15-plus depth layers and73-plus CX reduction.

These are bounded numerical searches with one deterministic perturbed start per selected template, not proofs that different eight-wire architectures cannot work. The actionable bottleneck is that removing entanglers creates large state-and-phase errors even after wider rotation refitting, while most of the required resource reduction lies outside either window. A promising next step must coordinate several interacting regions or change the nonlinear encoding/marking architecture, rather than repeat these failed isolated templates.

## Artifacts

- `wide_inventory.json`: structural search and selected window indices.
- `round1_support.npz`, `round2_support.npz`: full occupied bases and exact targets.
- `round1_results.json`, `round2_results.json`: all selected fit metrics and errors.
- `round1_DIAGNOSTIC.*`, `round2_DIAGNOSTIC.*`: invalid full circuits, common evaluations, and native verification results.
- `two_round_summary.json`: consolidated numerical records.

Source SHA256: `a95f05f9ea28c3d1db38760b19aaefceb378fa2889b5bb49a699c7fe67ce3be2`.
