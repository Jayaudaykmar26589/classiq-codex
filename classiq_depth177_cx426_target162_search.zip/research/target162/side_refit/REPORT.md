# Target162/354 — two further side-isometry restructuring rounds

The valid result remains **depth177, CX426, width18**. Neither strict target `depth<162 andCX<354` nor a lexicographic win over162/354 was achieved. Exactly **two restructuring rounds** were completed; protected outputs were not modified.

Both rounds started from the already validated x632/y671 removal architecture, retaining its fitted78 x-side and90 y-side U3 parameters. They did not repeat the old177/428 source's single-deletion scan. Targets are full phase-aware64-column isometries in the512-dimensional side space, with independent positive controls and clean-ancilla verification for complete circuits.

| Round | Restructuring | Valid depth | Valid CX | Width | New complete candidates |
|---|---|---:|---:|---:|---|
|1|One furtherCX deletion per side, independently refit every local U3|177|426|18|No accepted repair|
|2|Paired furtherCX deletions to expose nonadditive cancellations|177|426|18|No accepted repair|

Across both rounds, **1231 deletion topologies** were screened on the care contract; **83** promising or adjacent-pair topologies received native pricing. **48** perturbed-start optimization fits were run. Each fit was capped at150 L-BFGS iterations using the explicit aligned-complex-residual objective, with further high-precision refinement reserved for near-exact solutions. Each round's fitting/screening budget was140 seconds, checked between fits.

## Complete circuit diagnostics

These lower-CX diagnostics are invalid and must not be submitted.

| Round | Diagnostic | Depth | CX | Width | Verification |
|---|---|---:|---:|---:|---|
|1|y_best_invalid_diagnostic|177|425|18|FAIL|
|1|x_best_invalid_diagnostic|177|425|18|FAIL|
|2|y_best_invalid_diagnostic|177|424|18|FAIL|
|2|x_best_invalid_diagnostic|177|424|18|FAIL|

The remaining bottleneck is functional: the deleted entangling gates encode state or phase information that these bounded, fixed-position U3 refits did not recover. Reduced CX counts in an approximate circuit were not accepted as improvements. This does not prove any topology infeasible, and it does not establish a lower bound for an architecture that changes surrounding gates or coordinate encodings.

All complete circuit comparisons use the same Qiskit2.5.2 compilation: U3/CX basis, all-to-all coupling, optimization level3, seed42, `qubits_initially_zero=False`, no measurements/resets, exactly18 wires. Full diagnostic verification uses all4,096 coordinate inputs and checks relative oracle phases and helper cleanup. Local optimizer loss alone is never treated as oracle correctness. New target flags are explicitly stored in each evaluation JSON and this summary rather than relying on the evaluator's older177/428 flags.

The next useful change is to alter an entire interacting block's gate topology, including rotation positions or surrounding phase interactions, instead of deleting further gates from the same positions. Reproducible code, selected topologies, numerical fits, complete QASM diagnostics and verification JSON files are under this directory.
